@echo off
chcp 65001 > nul
cd /d "%~dp0"
title 🎬 SN TOOL - Create Desktop Shortcut
color 0a
cls

echo ========================================================================
echo  🎬 កំពុងបង្កើត Icon កម្មវិធី SN TOOL លើ Desktop...
echo ========================================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ws = New-Object -ComObject WScript.Shell; " ^
    "$desk = [System.Environment]::GetFolderPath('Desktop'); " ^
    "$sc = $ws.CreateShortcut(\"$desk\SN TOOL.lnk\"); " ^
    "$sc.TargetPath = \"wscript.exe\"; " ^
    "$sc.Arguments = '\"%~dp0LAUNCH_STUDIO_SILENT.vbs\"'; " ^
    "$sc.WorkingDirectory = \"%~dp0\"; " ^
    "$sc.IconLocation = \"%~dp0icon.ico,0\"; " ^
    "$sc.Description = 'SN TOOL (Khmer AI Drama Studio)'; " ^
    "$sc.Save(); " ^
    "Write-Host '[OK] បានបង្កើត Shortcut លើ Desktop រួចរាល់ដោយជោគជ័យ!' -ForegroundColor Green"

echo.
echo ========================================================================
echo  🎉 រួចរាល់! ឥឡូវបងអាចចុចបើកកម្មវិធីបានពីលើ Desktop ភ្លាមៗ (គ្មានផ្ទាំងខ្មៅ CMD)!
echo ========================================================================
echo.
pause
