{
  "manifest": {
    "license_engine.py": "d998835092fe5eab9cb0873b6a8a5e942c9e6f7b7a4ae6c7a1ea2844d8c58c86",
    "downloader.py": "9f31d6de8dd8bcf9850e83147eac9c0164b5d999cec1d6c835b3b4975ae17601",
    "translator.py": "5856bf9eafc1262cbef2bf0b9d42da5ce1e09e09013a97ea01b024cdd6e9c281",
    "pipeline.py": "3a7882c081aee024afab58372b075fdef0146a4eb7b594873bea938c44799e71",
    "series_memory.py": "c3247eea2eff3366950caf5124013a5e991fffac8b404b996b51f6376d9c8acf",
    "tts_engine.py": "451bafe4e7a192b24dbfa9f2351b1c0420d30c357d828c11f171be5b48c9bba2"
  },
  "signature": "af280653c9e83072148344aec1bafd3db1a96482ec65cabae30b3cc9bae9d342",
  "generated_at": 1795151077.3653543
}