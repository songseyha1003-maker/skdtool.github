{
  "manifest": {
    "license_engine.py": "8b236a6a7a3c7293a29ccaa4483fdc16d5cd83fb6020dbd28d923259077128ae",
    "downloader.py": "977d5e796acbb413bb1712ab154d9cb5cb439a6eef4bd2547df5ee1c0ca9308c",
    "translator.py": "eb731d7d88d534239dbb0cbd7f4522eb04508bb5ceb18fec9cb93d886d8627a2",
    "pipeline.py": "a0f1849308e48c06ad4492d0c34bab2d24889d21dee45d1d364118fbee2899f4",
    "series_memory.py": "c3247eea2eff3366950caf5124013a5e991fffac8b404b996b51f6376d9c8acf",
    "tts_engine.py": "3ffa02e45199b5077449a076311d409cd725ba9628b3bb54f621ad8564503387"
  },
  "signature": "8c2e4606916a48e32884c5c76e9d5ff49894c736b13d21b62cb406aeacc92355",
  "generated_at": 1793853929.4351988
}