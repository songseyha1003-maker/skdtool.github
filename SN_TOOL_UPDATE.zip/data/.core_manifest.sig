{
  "manifest": {
    "license_engine.py": "534901f3c135d3b55ca2b3fc931fb2dee95cace0e9fe573f3be644cdf750b73f",
    "downloader.py": "78ba6b31ceb98f4219258442b655874052e87428d6dd23fd64b2c13aad3d0978",
    "translator.py": "eb731d7d88d534239dbb0cbd7f4522eb04508bb5ceb18fec9cb93d886d8627a2",
    "pipeline.py": "076c7f164dc2d33a284579c27294680c1228f5d75157c7b5eba21caba969655a",
    "series_memory.py": "df65e9743ed12ebc789a4183af1e1918990a1cf63d227dd11c11c759e25a1634",
    "tts_engine.py": "3ffa02e45199b5077449a076311d409cd725ba9628b3bb54f621ad8564503387"
  },
  "signature": "9fd3230c061ca3f95416bc779949a9dcb8df27f671b391a7800e7be943443b74",
  "generated_at": 1793807216.1260288
}