{
  "manifest": {
    "license_engine.py": "d998835092fe5eab9cb0873b6a8a5e942c9e6f7b7a4ae6c7a1ea2844d8c58c86",
    "downloader.py": "9f31d6de8dd8bcf9850e83147eac9c0164b5d999cec1d6c835b3b4975ae17601",
    "translator.py": "f4be83eb4254970d478e37ced7c45f68c72feb905e2a902474a7bf79676886a1",
    "pipeline.py": "6255a49e5f50b7aa958d8b4bb83201045fde39b3febacfa6b1a365ae52586e07",
    "series_memory.py": "c3247eea2eff3366950caf5124013a5e991fffac8b404b996b51f6376d9c8acf",
    "tts_engine.py": "451bafe4e7a192b24dbfa9f2351b1c0420d30c357d828c11f171be5b48c9bba2"
  },
  "signature": "caf5cb1c1a48261e7ced1caf0213a11297516f323d8f6ddc448e9b3acd3e1e18",
  "generated_at": 1795138627.543296
}