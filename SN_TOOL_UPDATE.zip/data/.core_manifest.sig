{
  "manifest": {
    "license_engine.py": "534901f3c135d3b55ca2b3fc931fb2dee95cace0e9fe573f3be644cdf750b73f",
    "downloader.py": "78ba6b31ceb98f4219258442b655874052e87428d6dd23fd64b2c13aad3d0978",
    "translator.py": "eb731d7d88d534239dbb0cbd7f4522eb04508bb5ceb18fec9cb93d886d8627a2",
    "pipeline.py": "1b4745dd6122df20b439308dd2f374922bc22fc347e13692139f2ea85150da1c",
    "series_memory.py": "df65e9743ed12ebc789a4183af1e1918990a1cf63d227dd11c11c759e25a1634",
    "tts_engine.py": "3ffa02e45199b5077449a076311d409cd725ba9628b3bb54f621ad8564503387"
  },
  "signature": "010f867dc5b043c0b8cd9dbf2d19f0b9341863803b5b37a1b1c6f8b465302172",
  "generated_at": 1793808364.7293415
}